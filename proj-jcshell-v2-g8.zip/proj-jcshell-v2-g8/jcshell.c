/* 
*************************************************************************
jc-shell - exercicio 2, version 2									    *
Sistemas Operativos, DEI-CC/FC/UAN 2020								    *
*************************************************************************
Authors, Grupo : 8													    *
																	    *
Pedro Jose Manuel         	 	www.github.com/pedro-jmanuel		    *
Nkiambi Jeremias Antonio  	 	www.github.com/nkiambi-jeremias-antonio *
Makiesse Catarina Esteves File  www.github.com/makiesse-filipe		    *
Isabel Monanca Raul Antonio     www.github.com/isamoran					*
*************************************************************************
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>
#include "list.h"

#include "commandlinereader.h"

#define EXIT_COMMAND "exit"
#define MAXARGS 7
#define STATUS_INFO_LINE_SIZE 50
#define BUFFER_SIZE 100

/* Variaveis globais */

int numchildren;         //Armazena o numero de processos filhos criado.

list_t *lista_processos; //Armazena as informacoes dos processos lancados.

int termine;            //Recebe 1 se foi dada a instrucao exit, 0 por defeito

pthread_mutex_t numchildren_mtx = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t lista_processos_mtx = PTHREAD_MUTEX_INITIALIZER;


/* Funcao para monitorar os processos */

void * monitorar_processos(){
	
	  int status, childpid;
      
      while(1){
		  /*  
		  Testando ...
		   
		   */
		   
		  sleep(10);

		 /*	
			printf("\n numchildren = %i \n",numchildren);
			printf("termine = %i \n",termine);
		  
		  */
		  
		  //lst_print(lista_processos);
		   
		  if(numchildren > 0){
			childpid = wait(&status);

			if(childpid < 0){
			  if(errno == EINTR){
				continue;
			  }else{
				perror("Error waiting for child.");
				exit(EXIT_FAILURE);
			  }
			}
			printf("Terminou .. PID = %i \n",childpid);
			update_terminated_process(lista_processos, childpid, time(NULL));
			numchildren--;
		  }else{
			  sleep(1);
			  continue;
		  }
		  if(numchildren == 0 && termine == 1){
			 // printf("Bye Bye thread monitora Terminou ...\n");
			  return NULL;
		  }
      }
	return NULL;
}


int main(int argc, char **argv){
	

  lista_processos = lst_new();

  numchildren = 0;
  
  termine = 0;
  
  char *args[MAXARGS];

  char buffer[BUFFER_SIZE];

  //Criando uma thread para monitorar os processos

  pthread_t idt_monitora;
  
  int resposta = pthread_create(&idt_monitora,NULL,monitorar_processos,NULL); 
  
  if (resposta != 0) {
 	 perror("Thread creation failed");
	 exit(EXIT_FAILURE);
  }
   
 //Inicio do lancamentos dos processos
 
  printf("Insert your commands:\n");

  while (1){
    
	int numargs;

	if(termine == 1){
		pthread_join(idt_monitora,NULL);
		printf("Processo pai termina..");
		printf("atual numchildren =  %i ",numchildren);
	
		lst_print(lista_processos);
		break;
	}
	
    numargs = readLineArguments(args, MAXARGS, buffer, BUFFER_SIZE);

    if (numargs < 0 || (numargs > 0 && (strcmp(args[0], EXIT_COMMAND) == 0))){
      
	  termine = 1; // Informe a tarefa monitora para terminar  
	  
	 /*
	  int status, childpid;
      int message_size = numchildren * STATUS_INFO_LINE_SIZE;

      char *childstatusmessage = NULL;
      char aux[STATUS_INFO_LINE_SIZE];

	  
      if (numchildren > 0){
        childstatusmessage = (char *)malloc(message_size);
        childstatusmessage[0] = '\0';
      }

      while(numchildren > 0){
			childpid = wait(&status);

			if(childpid < 0){
			  if(errno == EINTR){
				continue;
			  }else{
				perror("Error waiting for child.");
				exit(EXIT_FAILURE);
			  }
			}

			if (WIFEXITED(status))
			  snprintf(aux, sizeof(aux), "pid: %d exited normally; status=%d\n",
					   childpid, WEXITSTATUS(status));
			else
			  snprintf(aux, sizeof(aux), "pid: %d terminated without calling exit\n",
					   childpid);
			strncat(childstatusmessage, aux, message_size);
			
			numchildren--;
      }

      if(childstatusmessage != NULL)
        printf("%s", childstatusmessage);
      exit(EXIT_SUCCESS);
	  */
    }else if (numargs > 0){
      	  
	  int pid = fork();

      if (pid < 0){
        perror("Failed to create new process.");
        exit(EXIT_FAILURE);
      }

      if (pid > 0){
        numchildren++;
		
		//Adicionando informacoes do processo lancado na lista
		
		insert_new_process(lista_processos,pid,time(NULL));
		
        continue;
      }else{
        if (execv(args[0], args) < 0){
          perror("Could not run child program. Child will exit.");
          exit(EXIT_FAILURE);
        }
      }
    }
  }   // Fim dos lancamentos dos processos
 
 
  //Espere pela terminacao da thread monitora
 
  //pthread_join(idt_monitora,NULL);
  
  //Libera lista
  	  
  lst_destroy(lista_processos);
}