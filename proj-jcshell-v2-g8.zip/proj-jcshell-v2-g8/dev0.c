#include <stdio.h>

int main(){
	int a, b, c;
	a = 5;
	b = 0;
	c = a / b;
	
	printf("c=%d\n",c);
	
	return 0;
}