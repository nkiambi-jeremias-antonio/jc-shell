#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include "commandlinereader.h"

/*
Authors: 
	Grupo : 8
	
	Pedro Jose Manuel         	 	www.github.com/pedro-jmanuel
	Nkiambi Jeremias Antonio  	 	www.github.com/nkiambi-jeremias-antonio
	Makiesse Catarina Esteves File  www.github.com/makiesse-filipe
	Isabel Monanca Raul Antonio     www.github.com/isamoran

*/

int main (int argc, char** argv){
 	
    char *args[7];
    char buffer[100];
    
     while(1){

	   // printf("Insert your commands: \n\n");
	   // int estado = 0;
		 readLineArguments(args,7, buffer,100);
               
         pid_t pid = fork();

         if(strcmp("exit",args[0]) == 0 ){
           exit(0);
         }else{
            if(pid == 0){
                if(execv(args[0], args) == -1){
                    printf("Could not run child program. Child will exit.: No such file or directory");
                    exit(0);
                }
            }else if(pid > 0){
				 //printf("pid: %d exited  normally ; status %i \n",pid,estado);
            }else{
                printf("Error creating process \n");
            }
       }
    }
}
