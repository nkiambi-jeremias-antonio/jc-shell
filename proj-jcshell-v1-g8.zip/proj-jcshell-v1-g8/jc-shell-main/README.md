# jc-shell
O projecto consiste em desenvolver uma shell, chamada jc-shell, que permite executar e monitorar lotes de programas em paralelo numa máquina multi-core.
